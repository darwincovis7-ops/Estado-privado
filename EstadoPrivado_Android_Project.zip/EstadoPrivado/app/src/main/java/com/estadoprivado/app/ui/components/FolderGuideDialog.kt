package com.estadoprivado.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.estadoprivado.app.ui.theme.TurquoisePrimary

@Composable
fun FolderGuideDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Cómo seleccionar la carpeta de estados", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "En Android moderno (11, 12, 13, 14 y 15), los archivos de WhatsApp se almacenan en la siguiente ruta:",
                    style = MaterialTheme.typography.bodyMedium
                )

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Android > media > com.whatsapp > WhatsApp > Media > .Statuses",
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                Text(
                    text = "WhatsApp Business:",
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyMedium
                )

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Android > media > com.whatsapp.w4b > WhatsApp Business > Media > .Statuses",
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                Text(
                    text = "Paso importante para archivos ocultos:",
                    fontWeight = FontWeight.SemiBold,
                    color = TurquoisePrimary
                )
                Text(
                    text = "La carpeta '.Statuses' tiene un punto al inicio. Si no la ves en el selector de Android, pulsa el menú de 3 puntos en la esquina superior derecha y selecciona 'Mostrar archivos ocultos'. Luego presiona 'USAR ESTA CARPETA'.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = TurquoisePrimary)
            ) {
                Text("Entendido")
            }
        }
    )
}
