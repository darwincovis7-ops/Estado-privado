package com.estadoprivado.app.data

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.TimeUnit

object StorageHelper {

    private const val PREFS_NAME = "estado_privado_prefs"
    private const val KEY_FOLDER_URI = "saved_folder_tree_uri"
    private const val KEY_DARK_THEME = "pref_dark_theme"

    fun saveSelectedFolderUri(context: Context, uri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        try {
            // Guardar permiso persistente en el sistema operativo Android
            context.contentResolver.takePersistableUriPermission(uri, flags)
        } catch (e: SecurityException) {
            e.printStackTrace()
        }

        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_FOLDER_URI, uri.toString())
            .apply()
    }

    fun getSavedFolderUri(context: Context): Uri? {
        val uriString = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_FOLDER_URI, null)
        return uriString?.let { Uri.parse(it) }
    }

    fun clearSavedFolder(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_FOLDER_URI)
            .apply()
    }

    fun saveThemePreference(context: Context, isDark: Boolean?) {
        val editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        if (isDark == null) {
            editor.remove(KEY_DARK_THEME)
        } else {
            editor.putBoolean(KEY_DARK_THEME, isDark)
        }
        editor.apply()
    }

    fun getThemePreference(context: Context): Boolean? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return if (prefs.contains(KEY_DARK_THEME)) {
            prefs.getBoolean(KEY_DARK_THEME, true)
        } else {
            null
        }
    }

    suspend fun loadStatusesFromTree(context: Context, treeUri: Uri): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        val rootDoc = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()

        if (!rootDoc.exists() || !rootDoc.isDirectory) {
            return@withContext emptyList()
        }

        val files = rootDoc.listFiles()
        for (file in files) {
            if (!file.isFile) continue
            val name = file.name ?: continue
            if (name.startsWith(".nomedia")) continue

            val mimeType = file.type ?: ""
            val lowerName = name.lowercase(Locale.ROOT)

            val isImage = mimeType.startsWith("image/") ||
                    lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") ||
                    lowerName.endsWith(".png") || lowerName.endsWith(".webp")

            val isVideo = mimeType.startsWith("video/") ||
                    lowerName.endsWith(".mp4") || lowerName.endsWith(".3gp") ||
                    lowerName.endsWith(".mkv")

            if (isImage) {
                items.add(
                    MediaItem(
                        uri = file.uri,
                        name = name,
                        type = MediaType.IMAGE,
                        sizeBytes = file.length(),
                        lastModified = file.lastModified(),
                        durationFormatted = null
                    )
                )
            } else if (isVideo) {
                val durationFormatted = extractVideoDuration(context, file.uri)
                items.add(
                    MediaItem(
                        uri = file.uri,
                        name = name,
                        type = MediaType.VIDEO,
                        sizeBytes = file.length(),
                        lastModified = file.lastModified(),
                        durationFormatted = durationFormatted
                    )
                )
            }
        }

        // Ordenar por fecha de modificación descendente (más recientes primero)
        items.sortedByDescending { it.lastModified }
    }

    private fun extractVideoDuration(context: Context, uri: Uri): String {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            retriever.release()

            val millis = time?.toLongOrNull() ?: 0L
            val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
            val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
            String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
        } catch (e: Exception) {
            "00:30"
        }
    }
}
