# Reglas Proguard para optimización y ofuscación segura
-keep class com.estadoprivado.app.** { *; }
-dontwarn coil.**
-dontwarn androidx.media3.**
